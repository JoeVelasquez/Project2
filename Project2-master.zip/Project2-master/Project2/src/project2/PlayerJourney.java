/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project2;
import java.util.Random;

/**
 *
 * @author Michael
 */
public class PlayerJourney extends PlayerClass{

    //PlayerJourney constructor
    public PlayerJourney(String firstName, String lastName) {
        super(firstName, lastName);
    }
    
    /**
     *
     */
    public void beginJourney(){
        
        System.out.printf("Let our journey begin!\n");
        Random rand = new Random();
        int roll = rand.nextInt(6) + 1;
        switch(roll){
            case 1: System.out.printf("You wake up in a dark forest with no memory of how you got here.\nYou hear the sound of enemies approaching you.\nYou quickly look around and see your trusty weapon; your grasp it and prepare for an upcoming fight!\n");
            break;
            case 2: System.out.printf("You're taking a stroll in your home town.\nIt is a bright and sunny day with all the regular townsfolk out and about performing their daily task.\nYou decide to head to the tavern to enjoy some grog and the company of others when a mystical portal opens below you and drops you into a Dungeon!\nThere are enemies in here that take quick notice of you.\nYou quickly draw your weapon and leap into a fight!\n");
            break;
            case 3: System.out.printf("You sit in a dank and dark cell.\nYou hear the cheers of a rabbid crowd outside.\nYou've been captured by strangers and have been told if you want to regain your freedom you must earn it in a series of fights to the death in the Arena.\nThe jailer knocks on your cell bars and alerts you it is your time to fight!\n");
            break;
            case 4: System.out.printf("You're sitting in a tavern.\nYou've had more than your fill of drink and the barkeep decides you should leave.\nAfter leaving the bar you stagger into a nearby field.\nTo your surprise a shadowy figure tries to sneak up on you.\n Time for a drunken fight! Your favorite.");
            break;
            case 5: System.out.printf("You are returning home from the local lake.\nWhat was supposed to be a full day of sun and fishing has quickly turned into dark storm clouds and rain.\nWith the fish you caught slung over one arm you realized something is approaching on you fast!\nYou ready your weapon and prepare to fight!");
            break;
            case 6: System.out.printf("Sometimes you feel like fighting.\nSo you picked up your weapon and started traveling down any path out of town.\nAs luck would have it, it seems that something wishes to challenge you.\nA figure leaps out of the brush hoping to surprise you but you're ready!");
            break;
        }
    }
    
}
